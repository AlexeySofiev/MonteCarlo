#include <iostream>
#include "randoms.h"

using namespace std;


void Ex1();
void Ex2();
void Ex3();
void Ex4();


int main()
{
    Ex1();
    Ex2();
    Ex3();
    Ex4();
    //cout << "Hello world!" << endl;
    return 0;
}
